﻿using InterChangeWeb.Models;
using InterChangeWeb.Models.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Controllers
{
    public class CurRateController : Controller
    {
        private ICurRateRepository repository;
        private readonly ILogger logger;
        public CurRateController(ICurRateRepository repo, ILogger<CurRateController> _logger)
        {
            repository = repo;
            logger = _logger;
        }
        public IActionResult Index()
        {
            var currate = repository.GetAll();
            
            return View(currate);
        }
        [HttpGet]
        public IActionResult Edit(string id)
        {
            CurrencyRate currate = repository.Get(id);
            return View(currate);
        }
        [HttpPost]
        public IActionResult Edit(CurrencyRate currate)
        {
            if (ModelState.IsValid)
            {
                repository.Update(currate);
                TempData["message"] = $"Курс обновлен";
                logger.LogInformation($"Курс обновлен. id:{currate.Id}  text: {currate.Rate}");
                return RedirectToAction("Index", "CurRate");

            }
            else
            {
                return View();
            }
        }
        public IActionResult Create() => View(new CurrencyRate());
        [HttpPost]

        public IActionResult Create(CurrencyRate cur)
        {

            if (ModelState.IsValid)
            {
                repository.Add(cur);
                TempData["message"] = $"Создан курс для валют успешно.";
                logger.LogInformation($"Создан курс для валют Currency:{cur.Currency}, Rate:{cur.Rate}");
                return RedirectToAction("Index", "CurRate");
            }
            else
            {
                return View();
            }
        }
        [HttpGet]
        public IActionResult Delete(string id)
        {
            CurrencyRate result = repository.GetDetails(id);
            return View(result);
        }
        [HttpPost]
        public IActionResult Delete(CurrencyRate cur)
        {
            repository.Delete(cur);
            TempData["message"] = $"Валюта и курс удален";
            logger.LogInformation($"Удаление валюты и курса Id:{cur.Id}, IdCurrencyRate:{cur.Currency}, IdTypePS:{cur.Rate}");
            return RedirectToAction("Index", "CurRate");

        }
        [HttpGet]
        public IActionResult Details(string id)
        {
            CurrencyRate result = repository.GetDetails(id);
            return View(result);
        }
    }
}
