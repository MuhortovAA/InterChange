﻿using InterChangeWeb.Models;
using InterChangeWeb.Models.Interfaces;
using InterChangeWeb.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Controllers
{
    public class TarifController : Controller
    {
        private ITarifRepository repository;
        private readonly ILogger logger;

        public TarifController(ITarifRepository repo, ILogger<TarifController> _logger)
        {
            repository = repo;
            logger = _logger;

        }

        public ViewResult List(string CurrentPS)
        {
            int? id = null;
            if (CurrentPS != null)
            {
                if (CurrentPS=="0")
                {
                    TarifListViewModel resultAll = new TarifListViewModel() { Tarifs = repository.GetTariffs(), CurrentPSId = "0" };
                    return View(resultAll);
                }
                else if (CurrentPS.ToUpper()!="ALL") id = Int32.Parse(CurrentPS);
                else
                {
                    TarifListViewModel resultAll = new TarifListViewModel() { Tarifs = repository.GetTariffs(), CurrentPSId = "0" };
                    return View(resultAll);

                }

            }
            TarifListViewModel result = new TarifListViewModel() { Tarifs = repository.GetTariffs().Where(p => CurrentPS == null || p.PSId == id), CurrentPSId = CurrentPS };
            return View(result);
        }


        public IActionResult Index()
        {
            var tariffs = repository.GetTariffs();
            return View(tariffs);
        }
        [HttpGet]
        public IActionResult Edit(string id)
        {
            Tarif tarif = repository.GetTarif(id);
            CreateModelTarif cmt = repository.GetCreateTarif();

            ViewBag.CurrencySpr = new SelectList(cmt.ISO, "Id", "Currency", tarif.IdCurrencyRate);
            ViewBag.PaymentSpr = new SelectList(cmt.PaymentSpr, "Id", "pName", tarif.IdTypePS);
            //ViewBag.PaymentSpr = new SelectList(result.PaymentSpr, "Id", "pName");

            //ViewBag.TypeOperations = new SelectList(cmt.TypeOperations, tarif.TypeOperation);
            ViewBag.TypeOperations = new SelectList(cmt.TypeOperations, "NameType", "NameType", tarif.TypeOperation.Trim());
            ViewBag.PayOperations = new SelectList(cmt.PayOperations, "Id", "NameOperation", tarif.PayOperation);

            return View(tarif);
        }
        [HttpPost]
        public IActionResult Edit(Tarif tarif)
        {
            if (ModelState.IsValid)
            {
                repository.Update(tarif);
                TempData["message"] = $"Тариф обновлен";
                logger.LogInformation($"Тариф обновлен. id:{tarif.Id}  text: {tarif.Percentage} TypeOperations:{tarif.TypeOperation}");
                return RedirectToAction("Index", "Tarif");
            }
            else
            {
                return View();
            }
        }

        public IActionResult Create()
        {
            var result = repository.GetCreateTarif();
            ViewBag.CurrencySpr = new SelectList(result.ISO, "Id", "Currency");
            ViewBag.PaymentSpr = new SelectList(result.PaymentSpr, "Id", "pName");
            ViewBag.TypeOperations = new SelectList(result.TypeOperations, "NameType", "NameType");
            ViewBag.PayOperations = new SelectList(result.PayOperations, "Id", "NameOperation");

            return View(result.tarif);
        }
        [HttpPost]

        public IActionResult Create(Tarif tarif)
        {

            if (ModelState.IsValid)
            {
                repository.Add(tarif);
                TempData["message"] = $"Тариф добавлен успешно.";
                logger.LogInformation($"Добавлен тариф IdCurrencyRate:{tarif.IdCurrencyRate}, IdTypePS:{tarif.IdTypePS}, MCC:{tarif.MCC}, PayOperation:{tarif.PayOperation}, Percentage:{tarif.Percentage}, TypeOperation:{tarif.TypeOperation}");
                return RedirectToAction("Index", "Tarif");
            }
            else
            {
                return View();
            }
        }
        [HttpGet]
        public IActionResult Delete(string id)
        {
            vTarif tarif = repository.GetTarifDetails(id);
            return View(tarif);
        }
        [HttpPost]
        public IActionResult Delete(Tarif tarif)
        {
            repository.Delete(tarif);
            TempData["message"] = $"Тариф удален";
            logger.LogInformation($"Удаление тарифа Id:{tarif.Id}, IdCurrencyRate:{tarif.IdCurrencyRate}, IdTypePS:{tarif.IdTypePS}, MCC:{tarif.MCC}, PayOperation:{tarif.PayOperation}, Percentage:{tarif.Percentage}, TypeOperation:{tarif.TypeOperation}");
            return RedirectToAction("Index", "Tarif");

        }
        [HttpGet]
        public IActionResult Details(string id)
        {
            vTarif tarif = repository.GetTarifDetails(id);
            return View(tarif);
        }

    }
}
