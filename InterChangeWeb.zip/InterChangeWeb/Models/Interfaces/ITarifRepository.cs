﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Models.Interfaces
{
    public interface ITarifRepository
    {
        IEnumerable<vTarif> GetTariffs();
        Tarif GetTarif(string id);
        vTarif GetTarifDetails(string id);
        void Update(Tarif tarif);
        void Save();
        CreateModelTarif GetCreateTarif();
        void Add(Tarif tarif);
        void Delete(Tarif tarif);
        List<CurrencyRate> GetAllCurRate();
    }
}
