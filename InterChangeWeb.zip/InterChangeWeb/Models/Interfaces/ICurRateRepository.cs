﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Models.Interfaces
{
    public interface ICurRateRepository
    {
        IEnumerable<vCurRate> GetAll();
        CurrencyRate Get(string id);
        void Update(CurrencyRate cur);
        void Add(CurrencyRate cur);
        void Save();
        CurrencyRate GetDetails(string id);
        void Delete(CurrencyRate cur);

    }
}
