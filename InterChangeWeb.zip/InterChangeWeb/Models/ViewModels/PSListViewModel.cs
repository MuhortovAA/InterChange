﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Models.ViewModels
{
    public class PSListViewModel
    {
        public List<vPSSpr> PSList { get; set; }

        public string CurrentPS { get; set; }
    }
}
