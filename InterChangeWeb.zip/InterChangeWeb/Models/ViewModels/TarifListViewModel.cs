﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Models.ViewModels
{
    public class TarifListViewModel
    {
        public IEnumerable<vTarif> Tarifs { get; set; }

        public string CurrentPSId { get; set; }
    }
}
