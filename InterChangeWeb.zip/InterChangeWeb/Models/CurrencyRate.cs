﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Models
{
    public class CurrencyRate
    {
        public int Id { get; set; }
        [Display(Name = "Валюта", Description = "")]
        public string Currency { get; set; }
        //[DisplayFormat(DataFormatString = "{0:############.000000}", ApplyFormatInEditMode =true)]
        [DisplayFormat(DataFormatString = "{0:N6}", ApplyFormatInEditMode = true)]

        [Display(Name = "Курс", Description = "")]
        public decimal Rate { get; set; }
    }
    public class vCurRate
    {
        public int Id { get; set; }
        [Display(Name = "Валюта", Description = "")]
        public string Currency { get; set; }
        //[DisplayFormat(DataFormatString = "{0:############.000000}")]
        [DisplayFormat(DataFormatString = "{0:N6}", ApplyFormatInEditMode = true)]
        [Display(Name = "Курс", Description = "")]
        public decimal Rate { get; set; }
    }
    public class spCurRate
    {
        public int Id { get; set; }
        [Display(Name = "Валюта", Description = "")]
        public string Currency { get; set; }
        //[DisplayFormat(DataFormatString = "{0:############.000000}")]
        [DisplayFormat(DataFormatString = "{0:N6}", ApplyFormatInEditMode = true)]
        [Display(Name = "Курс", Description = "")]
        public decimal Rate { get; set; }
    }
}
