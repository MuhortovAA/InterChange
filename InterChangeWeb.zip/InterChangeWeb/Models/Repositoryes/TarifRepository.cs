﻿using InterChangeWeb.Models.Context;
using InterChangeWeb.Models.Interfaces;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Models.Repositoryes
{
    public class TarifRepository : ITarifRepository
    {
        private ApplicationDbContext context;

        public TarifRepository(ApplicationDbContext ctx)
        {
            context = ctx;

        }
        public Tarif GetTarif(string id)
        {
            int iddata = Int32.Parse(id);
            var result = context.Tarif.Where(s => s.Id == iddata).FirstOrDefault();
            return result;
        }

        public IEnumerable<vTarif> GetTariffs() => context.vTarif;

        public void Save()
        {
            context.SaveChanges();
        }

        public void Update(Tarif tarif)
        {
            var tarifdata = new Tarif { Id=tarif.Id, IdCurrencyRate=tarif.IdCurrencyRate, IdTypePS=tarif.IdTypePS, MCC=tarif.MCC?.Trim()??"",  PayOperation=tarif.PayOperation, Percentage=tarif.Percentage, TypeOperation=tarif.TypeOperation };
            context.Tarif.Update(tarifdata);
            this.Save();
        }

        public void Add(Tarif tarif)
        {
            context.Add(tarif);
            this.Save();
        }

        public CreateModelTarif GetCreateTarif()
        {
            List<TypeOperationSpr> types = new List<TypeOperationSpr>() {
                new TypeOperationSpr{ NameType="LOC" },
                new TypeOperationSpr{ NameType="DOM" }
            };

            List<PayOperationSpr> pays = new List<PayOperationSpr> {
                new PayOperationSpr { Id = 0, NameOperation = "расход ПС" },
                new PayOperationSpr { Id = 1, NameOperation = "доход" },
                new PayOperationSpr { Id = 2, NameOperation = "расход Процессинг" },
            };

            CreateModelTarif tarif = new CreateModelTarif()
            {
                ISO = this.GetAllCurRate(),
                PaymentSpr = context.vPSSpr,
                tarif = new Tarif(),
                TypeOperations = types,
                PayOperations = pays
            };
            return tarif;
        }

        public List<CurrencyRate> GetAllCurRate()
        {
            List<CurrencyRate> result = context.CurrencyRate.FromSqlRaw("exec [dbo].[spCurRate]").ToList();
            return result;
        }

        public vTarif GetTarifDetails(string Id)
        {
            var IdTarif = new SqlParameter("@id", Id);
            vTarif result = context.vTarif.FromSqlRaw("exec [dbo].[GetTarifDetails] @id", IdTarif).ToList().FirstOrDefault();
            return result;
        }

        public void Delete(Tarif tarif)
        {
            context.Tarif.Remove(tarif);
            this.Save();
        }
    }
}
