﻿using InterChangeWeb.Models.Context;
using InterChangeWeb.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Models.Repositoryes
{
    public class PaymentSystemSprRepository : IPaymentSystemSpr
    {
        private ApplicationDbContext context;
        public PaymentSystemSprRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }
        public IEnumerable<vPSSpr> Get()
        {
            IEnumerable<vPSSpr> result = context.vPSSpr.ToList();
            return result;
        }
    }
}
