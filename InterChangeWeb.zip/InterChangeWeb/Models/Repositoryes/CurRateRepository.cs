﻿using InterChangeWeb.Models.Context;
using InterChangeWeb.Models.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Models.Repositoryes
{
    public class CurRateRepository : ICurRateRepository
    {
        private ApplicationDbContext context;

        public CurRateRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }
        public void Add(CurrencyRate cur)
        {
            context.CurrencyRate.Add(cur);
            this.Save();
        }

        public void Delete(CurrencyRate cur)
        {
            context.CurrencyRate.Remove(cur);
            this.Save();
        }

        public CurrencyRate Get(string id)
        {
            int iddata = Int32.Parse(id);
            var result = context.CurrencyRate.Where(s => s.Id == iddata).FirstOrDefault();
            return result;
        }

        public IEnumerable<vCurRate> GetAll() => context.vCurRate;

        //public IEnumerable<spCurRate> GetAllsp() => context.spCurRate;


        public CurrencyRate GetDetails(string id)
        {
            int iddata = Int32.Parse(id);
            var result = context.CurrencyRate.Where(s => s.Id == iddata).FirstOrDefault();
            return result;
        }

        public void Save()
        {
            context.SaveChanges();
        }

        public void Update(CurrencyRate cur)
        {
            context.CurrencyRate.Update(cur);
            this.Save();
        }
    }
}
