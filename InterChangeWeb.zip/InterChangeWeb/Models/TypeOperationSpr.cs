﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Models
{
    public class TypeOperationSpr
    {
        public string NameType { get; set; }
    }
}
