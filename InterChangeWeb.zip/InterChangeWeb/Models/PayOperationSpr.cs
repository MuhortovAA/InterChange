﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Models
{
    public class PayOperationSpr
    {
        public int Id { get; set; }
        public string NameOperation { get; set; }
    }
}
