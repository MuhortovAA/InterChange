﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Models.Context
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<vTarif> vTarif { get; set; }
        public DbSet<Tarif> Tarif { get; set; }
        public DbSet<CurrencyRate> CurrencyRate { get; set; }
        public DbSet<vCurRate> vCurRate { get; set; }
        public DbSet<vPSSpr> vPSSpr { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CurrencyRate>().Property(x => x.Rate).HasPrecision(18, 6);
            modelBuilder.Entity<Tarif>().Property(x => x.Percentage).HasPrecision(18, 3);

        }

    }
}
