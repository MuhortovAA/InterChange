﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Models
{
    public class Tarif
    {
        public int Id { get; set; }
        [Display(Name = "Платежная система", Description = "Платежная система в описании")]
        public int IdTypePS { get; set; }
        [Display(Name = "Валюта", Description = "")]
        public int? IdCurrencyRate { get; set; }
        public string TypeOperation { get; set; }
        [Display(Name = "МСС", Description = "")]
        public string MCC { get; set; }
        [DisplayFormat(DataFormatString = "{0:N3}", ApplyFormatInEditMode = true)]
        [Display(Name = "Процент", Description = "")]
        public decimal Percentage { get; set; }
        [Display(Name = "Платежная операция", Description = "")]
        public int PayOperation { get; set; }
    }
    public class vTarif
    {
        public int PSId { get; set; }
        public int Id { get; set; }
        [Display(Name = "Платежная система", Description = "Платежная система в описании")]
        public string PSName { get; set; }
        [Display(Name = "Валюта", Description = "")]
        public string Currency { get; set; }
        [Display(Name = "Курс", Description = "")]
        [DisplayFormat(DataFormatString = "{0:N6}")]
        public decimal Rate { get; set; }
        [Display(Name = "Операция", Description = "")]
        public string TypeOperation { get; set; }
        [Display(Name = "МСС", Description = "")]

        public string MCC { get; set; }
        [Display(Name = "Процент", Description = "")]
        [DisplayFormat(DataFormatString = "{0:N3}", ApplyFormatInEditMode = true)]
        public decimal Percentage { get; set; }
        [Display(Name = "Платежная операция", Description = "")]
        public string PayOperation { get; set; }
    }
    public class TarifDetail
    {
        public int Id { get; set; }
        public string PSName { get; set; }
        public string Currency { get; set; }
        public decimal Rate { get; set; }
        public string TypeOperation { get; set; }
        public string MCC { get; set; }
        public decimal Percentage { get; set; }
        public string PayOperation { get; set; }
    }
    public class CreateModelTarif
    {
        //public IQueryable<CurrencyRate> ISO { get; set; }
        public List<CurrencyRate> ISO { get; set; }

        public IQueryable<vPSSpr> PaymentSpr { get; set; }
        public List<TypeOperationSpr> TypeOperations { get; set; }
        public List<PayOperationSpr> PayOperations { get; set; }
        public Tarif tarif { get; set; }
    }
}
