﻿using InterChangeWeb.Models;
using InterChangeWeb.Models.Interfaces;
using InterChangeWeb.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Components
{
    public class FilterPSViewComponent : ViewComponent
    {
        private IPaymentSystemSpr repository;
        public FilterPSViewComponent(IPaymentSystemSpr repo)
        {
            repository = repo;
        }
        public IViewComponentResult Invoke()
        {
            ViewBag.SeletedFilter = RouteData?.Values["CurrentPS"];
            string id = RouteData?.Values["CurrentPS"]?.ToString() ?? "0";
            List<vPSSpr> ps = repository.Get().ToList();
            PSListViewModel result = new PSListViewModel() { PSList = ps, CurrentPS = id };
            //ViewBag.PaymentSpr = new SelectList(result, "Id", "pName", 1);
            return View(result);
        }
    }
}
