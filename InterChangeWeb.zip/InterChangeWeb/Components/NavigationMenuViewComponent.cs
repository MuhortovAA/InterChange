﻿using InterChangeWeb.Models;
using InterChangeWeb.Models.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InterChangeWeb.Components
{
    public class NavigationMenuViewComponent : ViewComponent
    {
        private IPaymentSystemSpr repository;
        public NavigationMenuViewComponent(IPaymentSystemSpr repo)
        {
            repository = repo;
        }
        public IViewComponentResult Invoke()
        {
            ViewBag.SeletedFilter = RouteData?.Values["psId"];
            IEnumerable<vPSSpr> result = repository.Get();
            return View(result);
        }
    }
}
