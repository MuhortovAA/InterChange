using InterChangeWeb.Models.Context;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using InterChangeWeb.Models.Interfaces;
using InterChangeWeb.Models.Repositoryes;
using System.Globalization;

namespace InterChangeWeb
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration) => Configuration = configuration;
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<ApplicationDbContext>(options => { options.UseSqlServer(Configuration["Data:InterChange:ConnectionString"]); });
            services.AddTransient<ITarifRepository, TarifRepository>();
            services.AddTransient<ICurRateRepository, CurRateRepository>();
            services.AddTransient<IPaymentSystemSpr, PaymentSystemSprRepository>();



            services.AddMvc();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseStatusCodePages();
            app.UseDefaultFiles();
            app.UseStaticFiles();
            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                
                endpoints.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");

                endpoints.MapControllerRoute(name: "PaymentSystem", pattern: "{controller=Tarif}/{action=List}/{CurrentPS}");

            });
            loggerFactory.AddFile("Logs/{Date}.log");
            //
            //var cultureInfo = new CultureInfo("fr-FR");
            //cultureInfo.NumberFormat.NumberDecimalSeparator = ".";
            //System.Threading.Thread.CurrentThread.CurrentUICulture = cultureInfo;

        }
    }
}
